nonstop — Complete HTML Package

index.html: standalone responsive e-commerce frontend/demo.
Included: 25 categories, responsive 3/4/5/6 product grid, search, sort, cart, quantity, Buy Now, checkout, RedX/Pathao/Sundarban delivery, bKash/Nagad manual payment flow, transaction ID, order confirmation/tracking, localStorage demo persistence, responsive admin dashboard UI, Bangla branding, mobile bottom navigation.

Production note: Firebase Authentication, Firestore, Storage and Security Rules must be connected for real authentication, admin authorization, stock/price validation, payment verification and secure persistence. Do not use browser demo OTP/localStorage as production security.
Admin reference: solaimanimran71@gmail.com
bKash/Nagad: +8801798504980
Delivery: RedX ৳80, Pathao ৳100, Sundarban ৳120
