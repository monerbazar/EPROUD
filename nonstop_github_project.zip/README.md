# nonstop

A responsive Bangla e-commerce storefront for the `nonstop` website.

## Included
- Responsive HTML storefront
- 25 category buttons
- Product grid, search and sorting
- Cart and checkout UI
- RedX / Pathao / Sundarban delivery options
- bKash / Nagad manual payment flow
- Transaction ID field
- Order confirmation and local order tracking
- Responsive admin dashboard UI
- 16:9 promotional banner

## Run
Open `index.html` in a browser.

## GitHub
```bash
git init
git add .
git commit -m "Initial nonstop website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nonstop.git
git push -u origin main
```

> This package is a standalone frontend/demo. Production Firebase Authentication, Firestore, Storage and Security Rules must be connected before using it as a real e-commerce backend.
